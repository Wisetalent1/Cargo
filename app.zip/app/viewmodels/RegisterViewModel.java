package com.nicargo.app.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.nicargo.app.models.OTPResponse;
import com.nicargo.app.models.RegistrationResponse;
import com.nicargo.app.models.UsernameCheckResponse;
import com.nicargo.app.network.ApiClient;
import com.nicargo.app.network.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterViewModel extends AndroidViewModel {
    private MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<OTPResponse> otpResponse = new MutableLiveData<>();
    private MutableLiveData<OTPResponse> verificationResult = new MutableLiveData<>();
    private MutableLiveData<UsernameCheckResponse> usernameCheckResult = new MutableLiveData<>();
    private MutableLiveData<RegistrationResponse> registrationResult = new MutableLiveData<>();
    private ApiInterface apiInterface;

    public RegisterViewModel(Application application) {
        super(application);
        apiInterface = ApiClient.getApiInterface();
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<OTPResponse> getOTPResponse() {
        return otpResponse;
    }

    public LiveData<OTPResponse> getVerificationResult() {
        return verificationResult;
    }

    public LiveData<UsernameCheckResponse> getUsernameCheckResult() {
        return usernameCheckResult;
    }

    public LiveData<RegistrationResponse> getRegistrationResult() {
        return registrationResult;
    }

    public void sendOTP(String email) {
        loading.setValue(true);
        error.setValue(null);

        apiInterface.sendOTP(email).enqueue(new Callback<OTPResponse>() {
            @Override
            public void onResponse(Call<OTPResponse> call, Response<OTPResponse> response) {
                loading.setValue(false);
                if (response.isSuccessful() && response.body() != null) {
                    otpResponse.setValue(response.body());
                } else {
                    error.setValue("Failed to send OTP. Please try again.");
                }
            }

            @Override
            public void onFailure(Call<OTPResponse> call, Throwable t) {
                loading.setValue(false);
                error.setValue("Network error. Please check your connection.");
            }
        });
    }

    public void verifyOTP(String email, String otp) {
        loading.setValue(true);
        error.setValue(null);

        apiInterface.verifyOTP(email, otp).enqueue(new Callback<OTPResponse>() {
            @Override
            public void onResponse(Call<OTPResponse> call, Response<OTPResponse> response) {
                loading.setValue(false);
                if (response.isSuccessful() && response.body() != null) {
                    verificationResult.setValue(response.body());
                } else {
                    error.setValue("Failed to verify OTP. Please try again.");
                }
            }

            @Override
            public void onFailure(Call<OTPResponse> call, Throwable t) {
                loading.setValue(false);
                error.setValue("Network error. Please check your connection.");
            }
        });
    }

    public void checkUsername(String username) {
        apiInterface.checkUsername(username).enqueue(new Callback<UsernameCheckResponse>() {
            @Override
            public void onResponse(Call<UsernameCheckResponse> call, Response<UsernameCheckResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    usernameCheckResult.setValue(response.body());
                }
            }

            @Override
            public void onFailure(Call<UsernameCheckResponse> call, Throwable t) {
                // Silently fail - don't show error for username checks
            }
        });
    }

    public void register(String email, String firstName, String lastName, String username,
                         String phone, String state, String password, 
                         String countryCode, String countryName) {
        loading.setValue(true);
        error.setValue(null);

        apiInterface.register(email, firstName, lastName, username, phone, state, 
                             password, countryCode, countryName)
                .enqueue(new Callback<RegistrationResponse>() {
                    @Override
                    public void onResponse(Call<RegistrationResponse> call, Response<RegistrationResponse> response) {
                        loading.setValue(false);
                        if (response.isSuccessful() && response.body() != null) {
                            registrationResult.setValue(response.body());
                        } else {
                            error.setValue("Registration failed. Please try again.");
                        }
                    }

                    @Override
                    public void onFailure(Call<RegistrationResponse> call, Throwable t) {
                        loading.setValue(false);
                        error.setValue("Network error. Please check your connection.");
                    }
                });
    }
}