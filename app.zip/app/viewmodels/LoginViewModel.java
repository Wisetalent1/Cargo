package com.nicargo.app.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.nicargo.app.models.LoginResponse;
import com.nicargo.app.network.ApiClient;
import com.nicargo.app.network.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginViewModel extends AndroidViewModel {
    private MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<LoginResponse> loginResult = new MutableLiveData<>();
    private ApiInterface apiInterface;

    public LoginViewModel(Application application) {
        super(application);
        apiInterface = ApiClient.getApiInterface();
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<LoginResponse> getLoginResult() {
        return loginResult;
    }

    public void login(String username, String password) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            error.setValue("Please fill in all fields");
            return;
        }

        loading.setValue(true);
        error.setValue(null);

        apiInterface.login(username, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                loading.setValue(false);
                
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();
                    if (loginResponse.isSuccess()) {
                        loginResult.setValue(loginResponse);
                    } else {
                        error.setValue(loginResponse.getMessage() != null ? 
                            loginResponse.getMessage() : "Login failed");
                    }
                } else {
                    if (response.code() == 401) {
                        error.setValue("Invalid credentials");
                    } else {
                        error.setValue("Login failed. Please try again.");
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                loading.setValue(false);
                error.setValue("Network error. Please check your connection.");
            }
        });
    }
}