package com.nicargo.app.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.nicargo.app.models.DashboardResponse;
import com.nicargo.app.models.Stats;
import com.nicargo.app.network.ApiClient;
import com.nicargo.app.network.ApiInterface;
import com.nicargo.app.utils.AuthTokenManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardViewModel extends AndroidViewModel {
    private MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<Stats> stats = new MutableLiveData<>();
    private MutableLiveData<Boolean> isUnauthorized = new MutableLiveData<>(false);
    private MutableLiveData<String> userName = new MutableLiveData<>();
    private ApiInterface apiInterface;
    private AuthTokenManager tokenManager;

    public DashboardViewModel(Application application) {
        super(application);
        apiInterface = ApiClient.getApiInterface();
        tokenManager = AuthTokenManager.getInstance(application);
        
        // Load user name from shared preferences
        String name = tokenManager.getUserName();
        if (name != null && !name.isEmpty()) {
            userName.setValue(name);
        } else {
            userName.setValue("User");
        }
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<Stats> getStats() {
        return stats;
    }

    public LiveData<Boolean> getIsUnauthorized() {
        return isUnauthorized;
    }

    public LiveData<String> getUserName() {
        return userName;
    }

    public void loadDashboardStats() {
        String token = tokenManager.getToken();
        if (token == null || token.isEmpty()) {
            isUnauthorized.setValue(true);
            return;
        }

        loading.setValue(true);
        error.setValue(null);
        isUnauthorized.setValue(false);

        apiInterface.getDashboardStats("Bearer " + token).enqueue(new Callback<DashboardResponse>() {
            @Override
            public void onResponse(Call<DashboardResponse> call, Response<DashboardResponse> response) {
                loading.setValue(false);
                
                if (response.isSuccessful() && response.body() != null) {
                    DashboardResponse dashboardResponse = response.body();
                    if (dashboardResponse.isSuccess() && dashboardResponse.getStats() != null) {
                        stats.setValue(dashboardResponse.getStats());
                    } else {
                        String msg = dashboardResponse.getMessage();
                        error.setValue(msg != null ? msg : "Failed to load dashboard stats");
                    }
                } else if (response.code() == 401) {
                    isUnauthorized.setValue(true);
                    error.setValue("Session expired. Please login again.");
                } else {
                    error.setValue("Failed to load dashboard stats. Please try again.");
                }
            }

            @Override
            public void onFailure(Call<DashboardResponse> call, Throwable t) {
                loading.setValue(false);
                error.setValue("Network error. Please check your connection.");
            }
        });
    }

    public void logout() {
        tokenManager.clear();
        isUnauthorized.setValue(true);
    }
}