package com.nicargo.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class AuthTokenManager {
    private static final String PREF_NAME = "nicargo_prefs";
    private static final String KEY_TOKEN = "auth_token";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_USERNAME = "user_username";
    private static final String KEY_USER_PHONE = "user_phone";
    
    private SharedPreferences sharedPreferences;
    private static AuthTokenManager instance;

    private AuthTokenManager(Context context) {
        sharedPreferences = context.getApplicationContext()
            .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized AuthTokenManager getInstance(Context context) {
        if (instance == null) {
            instance = new AuthTokenManager(context);
        }
        return instance;
    }

    public void saveToken(String token) {
        sharedPreferences.edit().putString(KEY_TOKEN, token).apply();
    }

    public String getToken() {
        return sharedPreferences.getString(KEY_TOKEN, null);
    }

    public void saveUserInfo(String name, String email, String username, String phone) {
        sharedPreferences.edit()
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_USER_USERNAME, username)
            .putString(KEY_USER_PHONE, phone)
            .apply();
    }

    public String getUserName() {
        return sharedPreferences.getString(KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return sharedPreferences.getString(KEY_USER_EMAIL, "");
    }

    public String getUserUsername() {
        return sharedPreferences.getString(KEY_USER_USERNAME, "");
    }

    public String getUserPhone() {
        return sharedPreferences.getString(KEY_USER_PHONE, "");
    }

    public boolean isLoggedIn() {
        return getToken() != null && !getToken().isEmpty();
    }

    public void clear() {
        sharedPreferences.edit().clear().apply();
    }
}